package org.autosalon.controllers;

import org.autosalon.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {

    @Autowired
    private ClientService clientService;

    @Autowired
    private EmployeeService employeeService;

    @Autowired
    private CatalogService catalogService;

    @Autowired
    private OrderService orderService;

    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("totalClients", clientService.getAllClients().size());
        model.addAttribute("totalEmployees", employeeService.getAllEmployees().size());
        model.addAttribute("totalProducts", catalogService.getAllProducts().size());
        model.addAttribute("totalRevenue", orderService.getTotalRevenue());
        return "index";
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        // Можно добавить больше статистики для дашборда
        return "dashboard";
    }
}
