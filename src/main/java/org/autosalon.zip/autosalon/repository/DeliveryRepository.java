package org.autosalon.repository;

import org.autosalon.model.Delivery;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface DeliveryRepository extends JpaRepository<Delivery, Long> {

    // Найти поставки по диапазону дат
    List<Delivery> findByDeliveryDateBetween(LocalDate startDate, LocalDate endDate);

    // Найти поставки после указанной даты
    List<Delivery> findByDeliveryDateAfter(LocalDate date);

    // Найти поставки до указанной даты
    List<Delivery> findByDeliveryDateBefore(LocalDate date);

    // Получить все поставки отсортированные по дате (новые сначала)
    @Query("SELECT d FROM Delivery d ORDER BY d.deliveryDate DESC")
    List<Delivery> findAllOrderByDateDesc();

    // Найти поставки по конкретной дате
    List<Delivery> findByDeliveryDate(LocalDate date);
}

