package org.autosalon.service;

import org.autosalon.model.Warehouse;
import org.autosalon.repository.WarehouseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class WarehouseService {

    @Autowired
    private WarehouseRepository warehouseRepository;

    public List<Warehouse> getAllWarehouseItems() {
        return warehouseRepository.findAll();
    }

    public Optional<Warehouse> getWarehouseItemById(Long id) {
        return warehouseRepository.findById(id);
    }

    public Warehouse saveWarehouseItem(Warehouse warehouseItem) {
        return warehouseRepository.save(warehouseItem);
    }

    public void deleteWarehouseItem(Long id) {
        warehouseRepository.deleteById(id);
    }

    public List<Warehouse> getAvailableItems() {
        return warehouseRepository.findAvailableItems();
    }

    public Integer getTotalQuantityByProduct(Long productId) {
        Integer quantity = warehouseRepository.getTotalQuantityByProductId(productId);
        return quantity != null ? quantity : 0;
    }

    public List<Warehouse> getItemsByProduct(Long productId) {
        return warehouseRepository.findByProductProductId(productId);
    }
}
