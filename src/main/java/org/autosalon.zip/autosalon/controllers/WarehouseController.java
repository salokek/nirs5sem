package org.autosalon.controllers;

import org.autosalon.model.Warehouse;
import org.autosalon.service.WarehouseService;
import org.autosalon.service.CatalogService;
import org.autosalon.service.DeliveryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.Optional;

@Controller
@RequestMapping("/warehouse")
public class WarehouseController {

    @Autowired
    private WarehouseService warehouseService;

    @Autowired
    private CatalogService catalogService;

    @Autowired
    private DeliveryService deliveryService;

    @GetMapping
    public String getAllWarehouseItems(Model model) {
        model.addAttribute("warehouseItems", warehouseService.getAllWarehouseItems());
        return "warehouse/list";
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("warehouseItem", new Warehouse());
        model.addAttribute("products", catalogService.getAllProducts());
        model.addAttribute("deliveries", deliveryService.getAllDeliveries());
        return "warehouse/add";
    }

    @PostMapping("/add")
    public String addWarehouseItem(@ModelAttribute("warehouseItem") Warehouse warehouseItem) {
        warehouseService.saveWarehouseItem(warehouseItem);
        return "redirect:/warehouse";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable("id") Long id, Model model) {
        Optional<Warehouse> warehouseItem = warehouseService.getWarehouseItemById(id);
        if (warehouseItem.isPresent()) {
            model.addAttribute("warehouseItem", warehouseItem.get());
            model.addAttribute("products", catalogService.getAllProducts());
            model.addAttribute("deliveries", deliveryService.getAllDeliveries());
            return "warehouse/edit";
        }
        return "redirect:/warehouse";
    }

    @PostMapping("/edit/{id}")
    public String updateWarehouseItem(@PathVariable("id") Long id,
                                      @ModelAttribute("warehouseItem") Warehouse warehouseItem) {
        warehouseItem.setRecordId(id);
        warehouseService.saveWarehouseItem(warehouseItem);
        return "redirect:/warehouse";
    }

    @GetMapping("/delete/{id}")
    public String deleteWarehouseItem(@PathVariable("id") Long id) {
        warehouseService.deleteWarehouseItem(id);
        return "redirect:/warehouse";
    }

    @GetMapping("/available")
    public String getAvailableItems(Model model) {
        model.addAttribute("warehouseItems", warehouseService.getAvailableItems());
        model.addAttribute("title", "Доступные автомобили на складе");
        return "warehouse/list";
    }
}