package org.autosalon.controllers;

import org.autosalon.model.Delivery;
import org.autosalon.service.DeliveryService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/deliveries")
public class DeliveryController {

    @Autowired
    private DeliveryService deliveryService;

    @GetMapping
    public String getAllDeliveries(Model model) {
        model.addAttribute("deliveries", deliveryService.getAllDeliveries());
        return "deliveries/list";
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("delivery", new Delivery());
        return "deliveries/add";
    }

    @PostMapping("/add")
    public String addDelivery(@Valid @ModelAttribute("delivery") Delivery delivery,
                              BindingResult result) {
        if (result.hasErrors()) {
            return "deliveries/add";
        }

        // Устанавливаем текущую дату, если не указана
        if (delivery.getDeliveryDate() == null) {
            delivery.setDeliveryDate(LocalDate.now());
        }

        deliveryService.saveDelivery(delivery);
        return "redirect:/deliveries";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable("id") Long id, Model model) {
        Optional<Delivery> delivery = deliveryService.getDeliveryById(id);
        if (delivery.isPresent()) {
            model.addAttribute("delivery", delivery.get());
            return "deliveries/edit";
        }
        return "redirect:/deliveries";
    }

    @PostMapping("/edit/{id}")
    public String updateDelivery(@PathVariable("id") Long id,
                                 @Valid @ModelAttribute("delivery") Delivery delivery,
                                 BindingResult result) {
        if (result.hasErrors()) {
            return "deliveries/edit";
        }

        delivery.setDeliveryId(id);
        deliveryService.saveDelivery(delivery);
        return "redirect:/deliveries";
    }

    @GetMapping("/delete/{id}")
    public String deleteDelivery(@PathVariable("id") Long id) {
        deliveryService.deleteDelivery(id);
        return "redirect:/deliveries";
    }

    @GetMapping("/search")
    public String searchDeliveries(@RequestParam(value = "date", required = false) String dateString,
                                   Model model) {
        if (dateString != null && !dateString.isEmpty()) {
            LocalDate date = LocalDate.parse(dateString);
            List<Delivery> deliveries = deliveryService.searchDeliveriesByDate(date);
            model.addAttribute("deliveries", deliveries);
            model.addAttribute("searchDate", dateString);
        } else {
            model.addAttribute("deliveries", deliveryService.getAllDeliveries());
        }

        return "deliveries/list";
    }

    @GetMapping("/recent")
    public String getRecentDeliveries(Model model) {
        model.addAttribute("deliveries", deliveryService.getRecentDeliveries());
        model.addAttribute("title", "Последние поставки (за последний месяц)");
        return "deliveries/list";
    }

    @GetMapping("/details/{id}")
    public String getDeliveryDetails(@PathVariable("id") Long id, Model model) {
        Optional<Delivery> delivery = deliveryService.getDeliveryById(id);
        if (delivery.isPresent()) {
            model.addAttribute("delivery", delivery.get());
            return "deliveries/details";
        }
        return "redirect:/deliveries";
    }
}