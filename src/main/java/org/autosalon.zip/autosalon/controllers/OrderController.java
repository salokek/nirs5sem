package org.autosalon.controllers;

import org.autosalon.model.*;
import org.autosalon.service.*;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Optional;

@Controller
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @Autowired
    private ClientService clientService;

    @Autowired
    private CatalogService catalogService;

    @Autowired
    private EmployeeService employeeService;

    @GetMapping
    public String getAllOrders(Model model) {
        model.addAttribute("orders", orderService.getAllOrders());
        return "orders/list";
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("order", new Order());
        model.addAttribute("clients", clientService.getAllClients());
        model.addAttribute("products", catalogService.getAllProducts());
        model.addAttribute("employees", employeeService.getAllEmployees());
        model.addAttribute("paymentStatuses", Order.PaymentStatus.values());
        return "orders/add";
    }

    @PostMapping("/add")
    public String addOrder(@Valid @ModelAttribute("order") Order order,
                           BindingResult result, Model model) {
        if (result.hasErrors()) {
            model.addAttribute("clients", clientService.getAllClients());
            model.addAttribute("products", catalogService.getAllProducts());
            model.addAttribute("employees", employeeService.getAllEmployees());
            model.addAttribute("paymentStatuses", Order.PaymentStatus.values());
            return "orders/add";
        }

        // Автоматический расчет общей стоимости
        if (order.getProduct() != null && order.getQuantity() != null) {
            BigDecimal total = order.getProduct().getPrice()
                    .multiply(BigDecimal.valueOf(order.getQuantity()));
            order.setTotalAmount(total);
        }

        if (order.getTransactionDate() == null) {
            order.setTransactionDate(LocalDate.now());
        }

        orderService.saveOrder(order);
        return "redirect:/orders";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable("id") Long id, Model model) {
        Optional<Order> order = orderService.getOrderById(id);
        if (order.isPresent()) {
            model.addAttribute("order", order.get());
            model.addAttribute("clients", clientService.getAllClients());
            model.addAttribute("products", catalogService.getAllProducts());
            model.addAttribute("employees", employeeService.getAllEmployees());
            model.addAttribute("paymentStatuses", Order.PaymentStatus.values());
            return "orders/edit";
        }
        return "redirect:/orders";
    }

    @PostMapping("/edit/{id}")
    public String updateOrder(@PathVariable("id") Long id,
                              @Valid @ModelAttribute("order") Order order,
                              BindingResult result, Model model) {
        if (result.hasErrors()) {
            model.addAttribute("clients", clientService.getAllClients());
            model.addAttribute("products", catalogService.getAllProducts());
            model.addAttribute("employees", employeeService.getAllEmployees());
            model.addAttribute("paymentStatuses", Order.PaymentStatus.values());
            return "orders/edit";
        }

        // Пересчет общей стоимости
        if (order.getProduct() != null && order.getQuantity() != null) {
            BigDecimal total = order.getProduct().getPrice()
                    .multiply(BigDecimal.valueOf(order.getQuantity()));
            order.setTotalAmount(total);
        }

        order.setOrderId(id);
        orderService.saveOrder(order);
        return "redirect:/orders";
    }

    @GetMapping("/delete/{id}")
    public String deleteOrder(@PathVariable("id") Long id) {
        orderService.deleteOrder(id);
        return "redirect:/orders";
    }

    @GetMapping("/client/{clientId}")
    public String getOrdersByClient(@PathVariable("clientId") Long clientId, Model model) {
        model.addAttribute("orders", orderService.getOrdersByClient(clientId));
        return "orders/list";
    }

    @PostMapping("/update-status/{id}")
    public String updateOrderStatus(@PathVariable("id") Long id,
                                    @RequestParam("status") Order.PaymentStatus status) {
        Optional<Order> orderOpt = orderService.getOrderById(id);
        if (orderOpt.isPresent()) {
            Order order = orderOpt.get();
            order.setPaymentStatus(status);
            orderService.saveOrder(order);
        }
        return "redirect:/orders";
    }
}
